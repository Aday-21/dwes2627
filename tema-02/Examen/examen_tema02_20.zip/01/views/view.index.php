<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap demo</title>
        <!-- CSS bootrstrap basico 5.3.8 -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
        <!-- icons bootstrap basico 5.3.8 -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    </head>
    <body>
    <!-- Capa principal de la aplicacion -->
        <div class="container mt-3">
            <header class="bg-primary text-white p-3 mb-3">
                <i class="bi bi-speedometer2"></i>
                <span class="fs-6">Título de aplicaicón</span>
            </header>
            <!-- contenido principal de la aplicacion -->
            <main>
                <!-- Formulario de la calculadora -->
                    <form method="post">
                        <!-- Campo velocidad inicial -->
                        <div class="mb-3">
                            <label for="velocidadInicial" class="form-label">Velocidad Inicial(m/s)</label>
                            <input type="number" class="form-control" step="0.01" placeholder="0.00" id="velocidadInicial" name="velocidadinicial" required>
                        </div>
                        <!-- Campo aceleración -->
                        <div class="mb-3">
                            <label for="aceleracion" class="form-label">Aceleración(m/s2)</label>
                            <input typ"ne=umber" class="form-control" step="0.01" placeholder="0.00" id="aceleracion" name="aceleracion" required>
                            
                        </div>  
                        <!-- Campo Tiempo -->
                        <div class="mb-3">
                            <label for="tiempo" class="form-label">Tiempo(s)</label>
                            <input typ"ne=umber" class="form-control" step="0.01" placeholder="0.00" id="tiempo" name="tiempo" required>
                        </div>
                        <!-- Campo Masa -->
                        <div class="mb-3">
                            <label for="masa" class="form-label">Masa(kg)</label>
                            <input typ"ne=umber" class="form-control" step="0.01" placeholder="0.00" id="masa" name="masa" required>
                        </div>
                        <div class="btn-group" role="group">
                            <button type="submit" class="btn btn-primary" value="calcular" formaction="calcular.php">Calcular</button>
                        </div>
                    </form>

            </main>
            <!-- pie de pagina de la aplicacion -->
            <footer class="footer mt-auto py-3 fixed-bottom bg-light">
                <div class="container">
                    <span class="text-muted">&copy; 2026
                        Aday Trandafir Garcia - DWES - 2º DAW - Curso 26/27</span>
                </div>
            </footer>
            <!-- js bootstrap basico 5.3.8 -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
        </div>
    </body>
</html>