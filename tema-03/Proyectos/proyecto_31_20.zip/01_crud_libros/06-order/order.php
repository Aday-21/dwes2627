<?php

/**
 * order.php
 *
 * permite ordenar de libros existente en la tabla de libros
 *
 * @package    CRUD Libros
 * @author     Tu Nombre
 * @version    1.0
 * 
 * Tabla  libros:
    *  - id 
    *  - titulo 
    *  - autor 
    *  - editorial 
    *  - generos 
    *  - precio 

*/

// Cargar librerias
require_once 'libs/functions.php';

// Models

// Negociado
// Obtener el criterio de ordenacion
// order.php?criterio=titulo - ordenar la tabla de libros por titulo
$criterio = htmlspecialchars($_GET['criterio'] ?? null);

// Validar el criterio recibido

// Cargar el array de libros
$libros = get_libros();

// Ordenar el array de libros según el criterio recibido
$array_criterio = array_column($libros, $criterio);
array_multisort($array_criterio, SORT_ASC, $libros);


// Cargo la vista principal con el array de libros actualizado
require_once 'views/show.view.php';



